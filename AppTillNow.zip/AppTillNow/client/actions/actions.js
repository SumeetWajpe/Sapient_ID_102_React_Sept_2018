export function IncrementLikes(index){
    return {
        type:'INCREMENT_LIKES',
        index:index
    }
}

export function AddComment(){
    return {
        type:'ADD_COMMENT'
    }
}

export function RemoveComment(){
    return {
        type:'REMOVE_COMMENT'
    }
}