import React ,{Component} from 'react';

export default class PostDetailsComponent extends Component{
    render(){    
        return <div className="postStyle">
                             <div className="row">
                                <div className="col-sm">                               
                                   <img src={this.props.postData.display_src} height="200px" width="200px" />
                                   </div>
                        </div>
                        <div className="row">
                                <div className="col-sm-8">
                                    <h2>{this.props.postData.caption}</h2>
                                </div>
                                <div className="col-sm-2">
                                    <button type="button" 
                                    onClick={this.props.IncrementLikes.bind(this,this.props.index)}
                                    className="btn btn-primary btn-lg">{this.props.postData.likes} &nbsp;
                                        <span className="glyphicon glyphicon-thumbs-up"></span>
                                    </button>
                                </div>
                        </div>
                    </div>
    }
}