import React ,{Component} from 'react';

export default class PostsComponent extends Component{
    render(){
        console.log(this.props.myposts)

        return <h1> Posts Component</h1>
    }
}