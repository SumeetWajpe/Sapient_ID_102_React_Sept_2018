export default function posts(defStore=[],action){

    switch(action.type){
        case 'INCREMENT_LIKES':
            // change the store !

            var indexOfPost = action.index;
          
            return [
                ...defStore.slice(0,indexOfPost),
                {...defStore[indexOfPost],likes:defStore[indexOfPost].likes + 1},
                ...defStore.slice(indexOfPost+1)
                ];


           
        default:
            return defStore;

    }
   
}