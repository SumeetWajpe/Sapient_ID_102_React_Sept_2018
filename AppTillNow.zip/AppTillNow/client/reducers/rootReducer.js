import comments from './commentsReducer';
import posts from './postsReducer';
import {combineReducers} from 'redux';
var rootReducer = combineReducers({
    posts:posts,comments:comments
});
export default rootReducer;