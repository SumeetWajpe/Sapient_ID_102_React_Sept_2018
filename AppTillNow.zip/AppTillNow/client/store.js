import {createStore} from 'redux';
import rootreducer from './reducers/rootReducer';
import posts from './data/posts';
import comments from './data/comments';

var defStoreData = {posts:posts,comments:comments}

var store = createStore(rootreducer,defStoreData);

export default store;
