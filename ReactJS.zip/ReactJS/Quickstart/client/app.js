// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
import CourseComponent,{PI,Add} from './course.component';
import ListOfCourses from './listofcourses.component';
import ButtonListComponent from './listofbuttons.component';
import LifeCycleComponent from './lifecycle.component';

// ReactDOM.render(<ListOfCourses />,
//     document.getElementById('content'))

// ReactDOM.render(<ButtonListComponent />,
//     document.getElementById('content'))

ReactDOM.render(<LifeCycleComponent /> ,document.getElementById('content'))