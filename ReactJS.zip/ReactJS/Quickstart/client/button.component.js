import React from 'react';
export default class ButtonComponent extends React.Component{
    render(){
        return <button>{this.props.count}</button>
    }
}

