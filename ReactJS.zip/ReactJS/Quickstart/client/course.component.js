import React from 'react';
export default class CourseComponent extends React.Component{
    render(){
        return <div className="CourseHighlight">
                        <h1>{this.props.coursedetails.name} </h1>
                        <img src={this.props.coursedetails.imageUrl} height="100px" width="100px" /> <br/>
                        <b>Price : </b> {this.props.coursedetails.price} <br/>
                        <b>Duration : </b> {this.props.coursedetails.duration} <br/>
                        <b>Rating : </b> {this.props.coursedetails.rating} <br/>

        </div> 
    }
}
export const PI = 3.14;
export function Add(x,y){
    return x + y;
}
