import React from 'react';
export default class LifeCycleComponent extends React.Component{
    
    constructor(){
        super();
        console.log('Within Constructor..');       
    }
    componentWillMount(){
        console.log('Within componentWillMount..');
        this.state = {companyName:''};
    }
    componentDidMount(){
        console.log('Within componentDidMount..');
    }
    OnChangeHandler(e){
            this.setState({companyName:e.target.value});// textbox.value
    }    
    shouldComponentUpdate(){
        console.log('Within shouldComponentUpdate..');


            if(arguments[1].companyName.length > 5){
                return false;
            }
            return true;
       
    }
    componentWillUpdate(){
        console.log('Within componentWillUpdate..');
    }
    componentDidUpdate(){
        console.log('Within componentDidUpdate..');
    }
    render(){
        console.log('Within Render..');
        return <div>
         Company :   <input type="text" 
         onChange={this.OnChangeHandler.bind(this)} /> <br/>
         You Entered : <h1>{this.state.companyName} </h1>
        </div>
    }
}

