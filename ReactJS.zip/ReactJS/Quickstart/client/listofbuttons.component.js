import React from 'react';
import ReactDOM from 'react-dom';
import ButtonComponent from './button.component';
export default class ButtonListComponent extends React.Component{
    constructor(){
        super();
        this.state = {listsofdata : [10,20,30,40,50]};
    }
    CalledOnClick(){
        // get the DOM Element
      let txtValue = ReactDOM.findDOMNode(this.refs.inputValue).value;
      this.setState({listsofdata: [...this.state.listsofdata,txtValue] })
    }
    render(){
        var buttonsToBecreated = this.state.listsofdata.map(
            (b)=> <ButtonComponent count={b} />
        )
        return <div>
            <input type="text" ref="inputValue" />
            <input type="button" value="Add"
             onClick={this.CalledOnClick.bind(this)} />

            {buttonsToBecreated}
        </div>
    }
}

