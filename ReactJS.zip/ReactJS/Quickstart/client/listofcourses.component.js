import React from 'react';  
import ReactDOM from 'react-dom';

import CourseComponent from './course.component';

export default class ListOfCourses extends React.Component{
    constructor(){
        super();
       this.state = {courses : [{name:"React",price:20000,duration:'3 Days',rating:4,imageUrl:'https://cdn-images-1.medium.com/max/1600/1*xkvjbVykgUr8I3nZntymsg.png'},
           {name:"Angular",price:30000,duration:'3 Days',rating:4,imageUrl:'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/1200px-Angular_full_color_logo.svg.png'},
           {name:"Node",price:25000,duration:'2 Days',rating:3,imageUrl:'https://cdn-images-1.medium.com/max/1200/1*9bVaonlM0iP8mSu45GzIeg.png'},
           {name:"VueJS",price:28000,duration:'4 Days',rating:5,imageUrl:'https://vuejs.org/images/logo.png'}]
    } 
 }  
    AddNewCourse(){

        let newCourse={};
        newCourse.name = ReactDOM.findDOMNode(this.refs.txtName).value;
        newCourse.price = ReactDOM.findDOMNode(this.refs.txtPrice).value;
        newCourse.rating = ReactDOM.findDOMNode(this.refs.txtRating).value;
        newCourse.duration = ReactDOM.findDOMNode(this.refs.txtDuration).value;

        this.setState({courses:[...this.state.courses,newCourse]})

    }
    render(){
        var lists = this.state.courses.map(
            (c,i)=> <CourseComponent coursedetails={c} key={i} />
        );
        return <div>
        <h1> Add new Course</h1>
        Name : <input type="text" ref="txtName" className="form-control" />
        Price : <input type="text" ref="txtPrice" className="form-control" />
        Rating : <input type="text" ref="txtRating" className="form-control" />
        Duration : <input type="text" ref="txtDuration" className="form-control" />
        <button className="btn btn-primary" onClick={this.AddNewCourse.bind(this)}>New Course <span className="glyphicon glyphicon-plus-sign"></span></button>            
       {lists}
    </div>
    }
}