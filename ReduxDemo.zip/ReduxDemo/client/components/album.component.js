import React ,{Component} from 'react';

export default class AlbumComponent extends Component{
    render(){
        return <h1> Album Component</h1>
    }
}