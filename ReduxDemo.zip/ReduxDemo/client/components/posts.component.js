import React ,{Component} from 'react';

export default class PostsComponent extends Component{
    render(){
        return <h1> Posts Component</h1>
    }
}