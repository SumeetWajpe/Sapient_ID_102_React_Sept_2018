export default function posts(defStore=[],action){

    switch(action.type){
        case 'INCREMENT_LIKES':
        console.log('Within Posts Reducer !');
        console.log(action.type);
            return defStore;
        default:
            return defStore;

    }
   
}