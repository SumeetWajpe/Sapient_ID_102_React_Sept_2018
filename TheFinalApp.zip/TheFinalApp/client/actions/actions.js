import axios from 'axios';

export function IncrementLikes(index){
    return {
        type:'INCREMENT_LIKES',
        index:index
    }
}

export function AddComment(){
    return {
        type:'ADD_COMMENT'
    }
}

export function RemoveComment(){
    return {
        type:'REMOVE_COMMENT'
    }
}

export function RemovePost(index){
    return {
        type:'REMOVE_POST',
        index
    }
}

export function FetchPostsData(){
    var request = axios.get('https://api.myjson.com/bins/t81sg');
    
    return (dispatch)=>{
        request.then(
            (response)=>{
                dispatch( {
                    type:'FETCH_POSTS_DATA',
                    response:response.data
                })
            }
        )
    }        
}