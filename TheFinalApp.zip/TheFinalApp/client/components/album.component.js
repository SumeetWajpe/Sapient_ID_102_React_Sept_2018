import React ,{Component} from 'react';
import PostDetailsComponent from './post.details.component';

export default class AlbumComponent extends Component{
    render(){
        // console.log(this.props.myposts)
        var postsToBeCreated = this.props.myposts.map(
            (p,i)=>{
                return <PostDetailsComponent 
                postData={p} 
                index={i}
                key={p.code}
                {...this.props}
                />
            }
        )
        return <div>
                        <h1 className="jumbotron"> Album </h1>
                           {postsToBeCreated}
                      

                </div>
    }
}