import React ,{Component} from 'react';
import {Link} from 'react-router';

export default class MainComponent extends Component{
  
  componentDidMount(){
    // making ajax request and update the store !
    //this.props.FetchPostsData();// calling the action creator !
  }
  
  render(){        

  

        return <div className="container-fluid">           
         
<nav className="navbar navbar-default">
  <div className="container-fluid">
     <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul className="nav navbar-nav">
        <li className="active">
        <Link to="/">Album </Link>
        </li>        
        <li><Link to="/posts"> Posts </Link></li>       
      </ul>         
    </div>
  </div>
</nav>
           {/* <AlbumComponent posts={this.props.myposts} /> Comment in JSX */}
                {React.cloneElement(this.props.children,this.props)} {/* For Dynamic Children*/}
        </div> 
    }
}