import React ,{Component} from 'react';
import {Link} from 'react-router';

export default class PostDetailsComponent extends Component{
    render(){    
        return <div className="postStyle">
                             <div className="row">
                                <div className="col-sm-10">     
                                <Link to={'/posts/'+this.props.postData.code}>                          
                                   <img src={this.props.postData.display_src} height="200px" width="200px" />
                                </Link>
                                   </div>
                                   <div className="col-sm-2"> 
                                      <button className="btn btn-danger" type="button" onClick={this.props.RemovePost.bind(this,this.props.index)} >
                                                 <span className="glyphicon glyphicon-trash"></span>
                                    </button>  
                                   </div>
                        </div>
                        <div className="row">
                                <div className="col-sm-8">
                                    <h2>{this.props.postData.caption}</h2>
                                </div>
                                <div className="col-sm-2">
                                    <button type="button" 
                                    onClick={this.props.IncrementLikes.bind(this,this.props.index)}
                                    className="btn btn-primary btn-lg">{this.props.postData.likes} &nbsp;
                                        <span className="glyphicon glyphicon-thumbs-up"></span>
                                    </button>
                                </div>
                        </div>
                    </div>
    }
}