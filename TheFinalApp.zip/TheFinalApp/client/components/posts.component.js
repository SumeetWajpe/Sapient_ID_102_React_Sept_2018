import React ,{Component} from 'react';
import PostDetailsComponent from './post.details.component';

export default class PostsComponent extends Component{
    render(){    

            // Fetch value  from query string !
            // console.log(this.props.location.query);

            // fetch the code from url (params) !
            let theCode = this.props.params.code;
            
            var currPost = this.props.myposts.find(
                (p)=>{
                    if(p.code == theCode){
                        return true;
                    }
                }
            );
            var index = this.props.myposts.findIndex(p=> p.code == theCode)

        return <div>
                <h1 className="jumbotron"> Posts Details </h1>
                <PostDetailsComponent 
                postData={currPost}
                index={index}
                {...this.props}                
                />

        </div>
    }
}