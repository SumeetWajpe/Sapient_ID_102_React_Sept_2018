export default function posts(defStore=[],action){

    switch(action.type){
        case 'FETCH_POSTS_DATA':
                    defStore = action.response;// the data received from the action
            return defStore;

            case 'REMOVE_POST':
            var indexOfPost = action.index;
            return [
                ...defStore.slice(0,indexOfPost),             
                ...defStore.slice(indexOfPost+1)
                ];

        case 'INCREMENT_LIKES':
            // change the store !

            var indexOfPost = action.index;
          
            return [
                ...defStore.slice(0,indexOfPost),
                {...defStore[indexOfPost],likes:defStore[indexOfPost].likes + 1},
                ...defStore.slice(indexOfPost+1)
                ];


           
        default:
            return defStore;

    }
   
}