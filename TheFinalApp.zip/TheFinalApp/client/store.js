import {createStore,applyMiddleware} from 'redux';
import thunk from 'redux-thunk';
import rootreducer from './reducers/rootReducer';
import posts from './data/posts';
import comments from './data/comments';


var defStoreData = {posts:posts,comments:comments}

// var store = createStore(rootreducer,
//     applyMiddleware(thunk));

var store = createStore(rootreducer,
    defStoreData,
    window.__REDUX_DEVTOOLS_EXTENSION__ &&
     window.__REDUX_DEVTOOLS_EXTENSION__());

export default store;
